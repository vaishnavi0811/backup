﻿param(
    [Parameter(Mandatory=$true)]

    $spnID,
    [Parameter(Mandatory=$true)]
    [securestring]
    $spnSecret,
    [Parameter(Mandatory=$true)]
    [string]
    $resourcegroupname
)

$cred = New-Object pscredential -ArgumentList $spnID,$spnSecret
Connect-AzAccount -Credential $cred -ServicePrincipal -Tenant a1319080-2db0-4f77-afdf-826779c04f8e

Get-AzResourceGroup -Name $resourcegroupname -ErrorVariable notPresent -ErrorAction SilentlyContinue | Format-Table

if ($notPresent) 
{
    Write-Output "Resource group doesnot exist"
    break
}

$output = "Resource Group,Resource,Firewall configuration" + "`r`n"


$filepath = "C:\output1.csv"
$resources = Get-AzResource -ResourceGroupName $resourcegroupname

foreach($resource in $resources)
{
    if($resource.ResourceType -eq "Microsoft.KeyVault/vaults")
    {
        $keyvaultname = $resource.Name
           
        $keyvaultnetwork = (Get-AzKeyVault -VaultName $name).NetworkAcls
            
        if($keyvaultnetwork.DefaultAction -eq "Allow")
        {
            $networkconfig = "Open to public"
        }
        else
        {
            $networkconfig = "Closed to public"
        }
            
        $output += $resourcegroupname + ',' + $keyvaultname + ',' + $networkconfig + ',' + "`r`n"
            
        }  

        if($resource.ResourceType -eq "Microsoft.Storage/storageAccounts")
        {
            $storageaccountname = $resource.Name
            $storagenetwork = Get-AzStorageAccountNetworkRuleSet -ResourceGroupName $resourcegroupname -AccountName $storageaccountname
            $storagenetwork

            if($storagenetwork.DefaultAction -eq "Allow")
            {
                $storagenetworkconfig = "Open to public"
            }
            else
            {
                $storagenetworkconfig = "Closed to public"
            }
            
            $output += $resourcegroupname + ',' + $storageaccountname + ',' + $storagenetworkconfig + ',' + "`r`n"
            
        }

    }

    $output | Out-File $filepath
