﻿$user = "na\admin_vm13"
$pwd = "**************"

$passSec = ConvertTo-SecureString $($Pwd) -AsPlainText -Force
$Credential = New-Object -TypeName System.Management.Automation.PSCredential -ArgumentList $user , $passSec

Copy-Item -Path "\\itsusrawsp03982\script_Test\samplefile.txt" -Destination "H:\My files"