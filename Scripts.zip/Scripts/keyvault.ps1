﻿$password = '7RQCGwj0Kk5vm-~rVeWsTyKZHP_.7Z~1I9'
$username = "73018c4d-4041-4435-a7a3-111d88aae22a"

$secret = ConvertTo-SecureString $password -AsPlainText -Force
$cred = New-Object pscredential -ArgumentList $username,$secret
Connect-AzAccount -Credential $cred -ServicePrincipal -Tenant a1319080-2db0-4f77-afdf-826779c04f8e


$resourcegroupname = "Testing"
Get-AzResourceGroup -Name $resourcegroupname -ErrorVariable notPresent

if ($notPresent)
{
     Write-Output "ResourceGroup doesn't exist"
}
else
{
    Write-Output "ResourceGroup exist"
}


$resources = Get-AzResource -ResourceGroupName Testing

foreach($resource in $resources)
{
    if($resource.ResourceType -eq "Microsoft.KeyVault/vaults")
    {
       $name = $resource.Name
       Write-Output "The keyvault name $name"
       
       $network = (Get-AzKeyVault -VaultName $name).NetworkAcls

       if($network.DefaultAction -eq "Allow")
       {
            Write-Output "The keyvault is open to public"
        }
        else
        {
            Write-Output "The keyvault is closed to public"
        }
    }    
   
}