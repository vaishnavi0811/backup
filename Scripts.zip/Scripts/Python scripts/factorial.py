def factorial(num):
    fact = 1
    for i in range (1,num+1):
        fact = fact * i
    return fact

input1 = int(input("Enter the number to find the factorial : "))
res = factorial(input1)
print ("The factorial of given number %d is %d" %(input1,res))