#Concatenating 2 inner list into a single list using nested for loop
list1=[['Azure','Terraform','AWS'],['Python','Java','Ruby']]
new_list=[]

for i in list1:
	for j in i:
		new_list.append(j)
print("Innerloop ends")	
print("The appended list is ",new_list)	