n = int(input("Enter the number of elements:"))
list1 = []
even_list=[]
odd_list=[]
i = 0
while (i < n):
	#if(i % 2 == 0)
	list1.append(i+1)
	i+=1
print("The numbers in the list are",list1)	
def switch_demo(arg):
	switcher = {
		1: odd_even(list1),
		2: fact(list1)
	}
	print (switcher.get(arg, "Invalid option"))
def odd_even(list2):
	for num in list2:
		if num%2==0:
			even_list.append(num)
			#print("The even numbers are",even_list)	
		else:
			odd_list.append(num)
			#print("The number",num,"is an odd number")	
	print("The even numbers are",even_list)		
	print("The odd numbers are",odd_list)
def fact(list2):
	for num in list2:
		if num < 0:
			print("Sorry, factorial does not exist for negative numbers")
		elif num == 0:
			print("The factorial of 0 is 1")
		else:
			for i in range(1,num+1):
				factorial = 1
				factorial = factorial*i
			print("The factorial of",num,"is",factorial)	
arg1 = int(input("Enter the option"))
switch_demo(arg1)