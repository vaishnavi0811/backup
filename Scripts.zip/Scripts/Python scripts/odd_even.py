input1 = int(input("Enter the number:"))
if input1%2==0:
	print("The number",input1,"is an even number")
else:
	print("The number",input1,"is an odd number") 	