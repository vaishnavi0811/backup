sample_string = "Hello World!!!"
print(sample_string[:7])
print(sample_string[4:])
print(sample_string[1:8])
print(sample_string[0:10:2])