a = 2525
b = 6898
if a > b:
    print("The number %d is greater than %d" %(a,b))
else:
    print("The number %d is greater than %d" %(b,a))

year = int(input("Enter the year"))
if (year % 4) == 0:
    print("The year {} is a leap year".format(year))
else:
    print("The year {} is not a leap year".format(year))    