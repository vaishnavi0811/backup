string1 = "Welcome to the world of Python"
str1 = string1.swapcase()
str2 = string1.casefold()
str3 = string1.title()
str4 = string1.upper()
str5 = string1.lower()
str6 = string1.center(20," ")
print(str1 + "\n" + str2 + "\n" + str3 + "\n" + str4 + "\n" + str5 + "\n" + str6)
print("Jan : {0} , Feb : {2} , Mar : {0} , Apr : {1} , May : {0} , June : {1} , July : {1} , Aug : {0} , Sep : {1} , Oct : {0} , Nov : {1} , Dec : {0}".format(31,30,28))