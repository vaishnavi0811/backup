year = int(input("Enter the year "))
if year % 4 == 0:
    #str(year)
    print ("The year {0} is a leap year".format(year))
else:
    print ("The year {0} is not a leap year".format(year))