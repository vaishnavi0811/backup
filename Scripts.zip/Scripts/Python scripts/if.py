age = int(input("Enter the age of the person:"))
if age <= 30:
    print("The person is a youngster")
elif (age > 30) and (age <=55):
    print("The person is a middle age")
elif (age > 55) and (age<=70):
    print("The person is a old age")
else:
    print("The person is very old")
