name = input("Enter the name: ")
print("My name is: ",name)