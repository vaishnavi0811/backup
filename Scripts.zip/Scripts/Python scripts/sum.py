a = int(input("Enter the 1st number: "))
b = int(input("Enter the 2nd number: "))
c = int(a + b)
print("Sum is: ",c)

a1 = int(input("Enter the 1st number: "))
b1 = int(input("Enter the 2nd number: "))
c1 = int(a1 + b1)
print("Difference is: ",c1)

a2 = int(input("Enter the 1st number: "))
b2 = int(input("Enter the 2nd number: "))
c2 = int(a2 + b2)
print("Product is: ",c2)

a3 = int(input("Enter the 1st number: "))
b3 = int(input("Enter the 2nd number: "))
c3 = int(a3 + b3)
print("Quotient is: ",c3)