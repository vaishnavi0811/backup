#Printing the list of cube values for given numbers in list using append()
num_list = [1,2,3,4,5]
cube_list=[]

for i in num_list:
	cube_list.append(i**3)
print("The new list is ",cube_list)	
	