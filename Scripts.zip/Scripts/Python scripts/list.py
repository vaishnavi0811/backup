my_list = ['aa','bb','cc','dd']
print("My list items are",my_list)

#if 'bb' in my_list:
	#print("The given element"+my_list)
for element in my_list:
	print("The element is "+element)		