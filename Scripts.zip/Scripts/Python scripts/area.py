import math
pi1 = math.pi
rad = int(input("Enter the radius"))
area = str(pi1 * (rad**2))
print ("The area of the circle is " + area)