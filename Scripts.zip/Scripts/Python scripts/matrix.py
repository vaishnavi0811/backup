row = int(input("enter the number of rows: "))
col = int(input("enter the number of columns: "))
matrix1 = []
matrix2 = []
sum1 = matrix1[:][:]
#To get the elements of a matrix1
print ("Enter the elements of matrix1")
for i in range(row):
    a = []
    for j in range(col):
        a.append(int(input()))
    matrix1.append(a)
#To get the elements of a matrix2
print ("Enter the elements of matrix2")
for i in range(row):
    b = []
    for j in range(col):
        a.append(int(input()))
    matrix2.append(b)   
#To add the 2 given matrix
for i in range(row):
    #c = matrix1[:][:]
    for j in range(col):
        sum1[i][j] = matrix1[i][j] + matrix2[i][j]
        #sum1[i][j].append(c[i][j])
        print(sum1[i][j], " ", end = " ")
    print()  