double_digit_evens = [e*2 for e in range(5, 50)] #example for list
print (double_digit_evens)
double_digit_odds = {e*2+1 for e in range(5, 50)} #example for set
print (double_digit_odds)
tens_series = {e: e*10 for e in range(1, 11)} #example for dictionaries
print(tens_series)
tuple1 = tuple(e*2 for e in range(5, 50))
print (tuple1)
tuple2 =tuple((10,20,30,40,10,70,30,50,80,10))
count1=tuple2.count(10)
print ("Count of 10s occurrence",count1)
tuple3 = tuple2.index(40)
print("The index of 40 is ",tuple3)
