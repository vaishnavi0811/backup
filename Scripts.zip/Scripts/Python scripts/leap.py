#Printing the leap years in 21st century using range()
for i in range(2000,2100):
	res= i % 4
	if res == 0:
		print("The year "+str(i)+" is a leap year")