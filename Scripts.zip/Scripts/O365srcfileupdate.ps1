﻿$srcpath = 'H:\Office365PreProd\O365\SRC\Office\Data'
$destpath = 'H:\PackageSource\Office 365\SRC\Office\Data'
$source = 'H:\Office365PreProd\O365'
$destination = 'H:\PackageSource\Office 365'
$backup = 'H:\O365backup'

#$newversion = '13801.20808'

$destcontent = Get-ChildItem -Recurse -Path $destpath -Directory
$destdirectory = ($destcontent.Name).Split(".")
$oldversion = $destdirectory[-2] + "." + $destdirectory[-1]
$oldversion

$srccontent = Get-ChildItem -Recurse -Path $srcpath -Directory
$srcdirectory = ($srccontent.Name).Split(".")
$newversion = $srcdirectory[-2] + "." + $srcdirectory[-1]
$newversion

if ($oldversion -ne $newversion)
{
    Remove-Item -Path $backup\* -Recurse -Force -Verbose -ErrorAction Stop
    if(!(Test-Path $backup\*))
    {
        Copy-Item -Recurse -Path $destination\* -Destination $backup -Verbose -ErrorAction Stop
        if(Test-Path $backup\*)        {
            Write-Output "Backup files are copied"
        }
        else        {
            Write-Output "backup copy failed"
        }
    }

    else    {
        Write-Output "All files are not deleted"
    }
    
    Remove-Item -Path $destination\* -Recurse -Force -Verbose -ErrorAction Stop
    if(!(Test-Path $destination\*))    {
        Copy-Item -Recurse -Path $source\* -Destination $destination -Verbose -ErrorAction Stop
        if(Test-Path $destination\*)        {
            Write-Output "Current source files are copied"
        }
        else        {
            Write-Output "Source file copy failed"
        }
    }
    else    {
        Write-Output "Previous version files are not removed"
    }
}

else{
    Write-Output "Changes already done!!"
}

Update-CMDistributionPoint -PackageId "C010337E"