﻿$srcpath = 'H:\test\154.zip'
$destpath = 'H:\test\unzipfiles'

Expand-Archive -LiteralPath $srcpath -DestinationPath $destpath