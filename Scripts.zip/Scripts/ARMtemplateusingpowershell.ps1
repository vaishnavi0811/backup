﻿param(
    [Parameter(Mandatory=$true)]
    $spnID,
    [Parameter(Mandatory=$true)]
    [securestring]
    $spnSecret,
    [Parameter(Mandatory=$true)]
    [string]
    $resourcegroupname,
    [Parameter(Mandatory=$true)]
    [string]
    $location,
    [Parameter(Mandatory=$true)]
    [string]
    $staname,
    [Parameter(Mandatory=$true)]
    [string]
    $acctype,
    [Parameter(Mandatory=$true)]
    [string]
    $kind,
    [Parameter(Mandatory=$true)]
    [string]
    $accesstier,
    [Parameter(Mandatory=$true)]
    [string]
    $mintlsversion,
    [Parameter(Mandatory=$true)]
    [string]
    $netaclsbypass,
    [Parameter(Mandatory=$true)]
    [string]
    $netaclsdefaultaction
)

$cred = New-Object pscredential -ArgumentList $spnID,$spnSecret
Connect-AzAccount -Credential $cred -ServicePrincipal -Tenant a1319080-2db0-4f77-afdf-826779c04f8e

Get-AzResourceGroup -Name $resourcegroupname -ErrorVariable notPresent -ErrorAction SilentlyContinue | Format-Table

if ($notPresent) 
{
    Write-Output "Resource group doesnot exist"
    break
}

$parameters = @{}
$parameters.Add("location",$location)
$parameters.Add("storageAccountName",$staname)
$parameters.Add("accountType",$acctype)
$parameters.Add("kind",$kind)
$parameters.Add("accessTier",$accesstier)
$parameters.Add("minimumTlsVersion",$mintlsversion)
$parameters.Add("supportsHttpsTrafficOnly",$true)
$parameters.Add("allowBlobPublicAccess",$true)
$parameters.Add("networkAclsBypass",$netaclsbypass)
$parameters.Add("networkAclsDefaultAction",$netaclsdefaultaction)

New-AzResourceGroupDeployment -ResourceGroupName $resourcegroupname -TemplateFile "Z:\template (1)\template.json" -TemplateParameterObject $parameters -Mode Incremental -Verbose


