﻿$user = "na\admin_vm13"
$pwd = "Password@032021"

$passSec = ConvertTo-SecureString $($Pwd) -AsPlainText -Force
$Credential = New-Object -TypeName System.Management.Automation.PSCredential -ArgumentList $user , $passSec

$Version = @{}
$Version = $PSVersionTable
$Version
#$Version.GetType()
$major = $Version.PSVersion.Major
$minor = $Version.PSVersion.Minor
$build = $Version.PSVersion.Build
$revision = $Version.PSVersion.Revision
#$value = ""
$value = "$major"+"."+"$minor"+"."+"$build"+"."+"$revision"
return $value

$user = "\winusr"
$pwd = "Password@2021"

$passSec = ConvertTo-SecureString $($Pwd) -AsPlainText -Force
$Credential = New-Object -TypeName System.Management.Automation.PSCredential -ArgumentList $user , $passSec

Invoke-Command -ComputerName "test01" -ScriptBlock {$PSVersionTable.PSVersion}