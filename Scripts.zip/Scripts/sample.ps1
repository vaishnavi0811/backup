﻿$password = 'Jycvu2a0pS.lI~1g66Ir5~j~3Bdc_5YbAf'
$username = "83b01e87-bcf7-4c39-9b55-093e66db8524"

$secret = ConvertTo-SecureString $password -AsPlainText -Force
$cred = New-Object pscredential -ArgumentList $username,$secret
Connect-AzAccount -Credential $cred -ServicePrincipal -Tenant a1319080-2db0-4f77-afdf-826779c04f8e

$resources = Get-AzResource -ResourceGroupName Learning
foreach($resource in $resources){
    Write-Output $resource.ResourceGroupName
}