﻿$json = Get-Content "H:\SCCM\Scripts\simplejson.json" | ConvertFrom-Json
$date = Get-Date -Format "yyyy-MM-ddTHHmms"
$excelfile = "H:\SCCM\Scripts\newxls_$date.xlsx"

Import-Module ImportExcel

#Export-Excel $excelfile -WorksheetName 
$json | Get-Member -MemberType NoteProperty | ForEach-Object {
    $key = $_.Name
    Write-Host $key
    $value = $json."$key"
    $value

    foreach($k in $value){
        
      $k | Export-Excel $excelfile -WorksheetName $key -AutoSize -Append -FreezeTopRow
   
    }

    #$xls = Open-ExcelPackage -Path $excelfile
    #Export-Excel -ExcelPackage $xls -WorksheetName $key -Title "compliance scan"
    
   # Close-ExcelPackage $xls

}

#$xls = Open-ExcelPackage -Path $excelfile
    #Export-Excel $excelfile -WorksheetName $key -Title $key
    #Set-ExcelRow -ExcelPackage $xls -WorksheetName "compliance" -Heading "Compliance" -Value "Compliance" -HeadingBold