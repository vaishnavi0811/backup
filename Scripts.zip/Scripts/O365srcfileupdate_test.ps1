﻿$srcpath = 'D:\srcfolder\SRC'
$destpath = 'D:\packagetesting\SCCMClient\SRC'
$source = 'D:\srcfolder'
$destination = 'D:\packagetesting\SCCMClient'
$backup = 'D:\backup'

$destcontent = Get-ChildItem -Recurse -Path $destpath -Directory
$destdirectory = ($destcontent.Name).Split(".")
$oldversion = $destdirectory[-2] + "." + $destdirectory[-1]
#$oldversion = '2010'

$srccontent = Get-ChildItem -Recurse -Path $srcpath -Directory
$srcdirectory = ($srccontent.Name).Split(".")
$newversion = $srcdirectory[-2] + "." + $srcdirectory[-1]
#$newversion = '2103'

if ($oldversion -ne $newversion)
{
    Remove-Item -Path $backup -Recurse -Verbose
    Copy-Item -Recurse -Path $destination -Destination $backup -Verbose

    Remove-Item -Path $destination -Recurse -Verbose
    Copy-Item -Recurse -Path $source -Destination $destination -Verbose
}

else
{
    Write-Output "Changes already done!!"
}

Update-CMDistributionPoint -PackageId "QC10001B"