﻿param(
[Parameter(Mandatory=$true)]
    [string]
    $servername)

$user = "\winadmin"
$pwd = "Password@2021"

$passSec = ConvertTo-SecureString $($Pwd) -AsPlainText -Force
$Credential = New-Object -TypeName System.Management.Automation.PSCredential -ArgumentList $user , $passSec

Get-WindowsOptionalFeature -Online