﻿#To allow the network access by default
$default = Update-AzStorageAccountNetworkRuleSet -ResourceGroupName "Learning" -Name "storagaccount" -DefaultAction Allow
$default

$vnetrules = (Get-AzStorageAccountNetworkRuleSet -ResourceGroupName "Learning" -AccountName "storagaccount").VirtualNetworkRules
$vnetrules

Update-AzStorageAccountNetworkRuleSet -ResourceGroupName "myresourcegroup" -Name "mystorageaccount" -VirtualNetworkRule  

#Adding vnet to a storage acocunt

#$subnet = Get-AzVirtualNetwork -ResourceGroupName "Learning" -Name "myvnet01" | Get-AzVirtualNetworkSubnetConfig -Name "subnet01"
#$subnet
#Add-AzStorageAccountNetworkRule -ResourceGroupName "Learning" -Name "storagaccount" -VirtualNetworkResourceId $su

Update-AzStorageAccountNetworkRuleSet -ResourceGroupName Learning -AccountName "storagaccount" -Bypass Logging,Metrics -DefaultAction Allow -IpRule (@{IPAddressOrRange="10.0.0.0/24";Action="allow"},@{IPAddressOrRange="28.2.0.0/16";Action="allow"})