﻿$jsonfile = "H:\SCCM\Scripts\simplejson.json"
$file
$json = ConvertFrom-JSON (Get-Content $jsonfile -Raw)
$json
$csvfile = "H:\SCCM\Scripts\output.csv"

foreach ($k in $json.keyvault)
{
    $k
    $k | Export-Csv $csvfile -Append
}

foreach ($k in $json.storageaccount)
{
    $k
    $k | Export-Csv $csvfile -Append
}


$delimiter = ","
$excelfile = "H:\SCCM\Scripts\output1.xlsx"
$excel = New-Object -ComObject excel.application 
$workbook = $excel.Workbooks.Add(1)
$worksheet1 = $workbook.worksheets.Item(1)
$worksheet2 = $workbook.worksheets.Item(2)

$TxtConnector = ("TEXT;" + $csvfile)
$Connector = $worksheet.QueryTables.add($TxtConnector,$worksheet.Range("A1"))
$query = $worksheet.QueryTables.item($Connector.name)
$query.TextFileOtherDelimiter = $delimiter

# Execute & delete the import query
$query.Refresh()
$query.Delete()

# Save & close the Workbook as XLSX.
$Workbook.SaveAs($excelfile,51)
$excel.Quit()