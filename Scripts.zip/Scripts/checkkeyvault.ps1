﻿$password = '7RQCGwj0Kk5vm-~rVeWsTyKZHP_.7Z~1I9'
$username = "73018c4d-4041-4435-a7a3-111d88aae22a"

$secret = ConvertTo-SecureString $password -AsPlainText -Force
$cred = New-Object pscredential -ArgumentList $username,$secret
Connect-AzAccount -Credential $cred -ServicePrincipal -Tenant a1319080-2db0-4f77-afdf-826779c04f8e

#To get the resource groups from current subscription
$resourcegroups = Get-AzResourceGroup
#$resourcegroupname.GetType()

foreach($resourcegroup in $resourcegroups)
{
    $resorcegroupname = $resourcegroup.ResourceGroupName

    $resources = Get-AzResource -ResourceGroupName $resorcegroupname

    foreach($resource in $resources)
    {
        if($resource.ResourceType -eq "Microsoft.KeyVault/vaults")
        {
            $name = $resource.Name
            Write-Output "The keyvault name $name"
       
            $network = (Get-AzKeyVault -VaultName $name).NetworkAcls
            $network

            if($network.DefaultAction -eq "Allow")
            {
                Write-Output "The keyvault is open to public"
            }
            else
            {
                Write-Output "The keyvault is closed to public"
            }
        }    
   }
}