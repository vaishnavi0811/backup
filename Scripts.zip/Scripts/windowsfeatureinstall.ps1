﻿param(
[Parameter(Mandatory=$true)]
    [string]
    $servername)

$user = "\winadmin"
$pwd = "Password@2021"

$passSec = ConvertTo-SecureString $($Pwd) -AsPlainText -Force
$Credential = New-Object -TypeName System.Management.Automation.PSCredential -ArgumentList $user , $passSec

Get-WindowsOptionalFeature -Online | where FeatureName -like 'IIS-*'
$list = @("IIS-WebServerRole","IIS-HttpRedirect","IIS-RequestMonitor","IIS-HttpTracing","IIS-HttpCompressionDynamic","IIS-WindowsAuthentication",`
"IIS-NetFxExtensibility","IIS-NetFxExtensibility45","IIS-ISAPIExtensions","IIS-ISAPIFilter","IIS-ASPNET","IIS-ASPNET45","IIS-WMICompatibility","IIS-Metabase")

foreach ($feature in $list)
{
    
    Enable-WindowsOptionalFeature -online -FeatureName $feature
}