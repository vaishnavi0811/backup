﻿param(
    [Parameter(Mandatory=$true)]
    [string]
    $spnID,
    [Parameter(Mandatory=$true)]
    [string]
    $spnSecret,
    [Parameter(Mandatory=$true)]
    [string]
    $subscription,
    [Parameter(Mandatory=$true)]
    [string]
    $omsResourceGroup
)

$pass = ConvertTo-SecureString $spnSecret -AsPlainText -Force
$cred = New-Object -TypeName pscredential -ArgumentList $spnID, $pass
Connect-AzAccount -Credential $cred -Tenant 5b973f99-77df-4beb-b27d-aa0c70b8482c -ServicePrincipal

Set-Item Env:\SuppressAzurePowerShellBreakingChangeWarnings "true"

$date = Get-Date -Format "yyyy-MM-ddTHH:mm:s"
Set-AzContext $subscription
$subscription_name = (Get-AzContext).Subscription.Name

Function get-oms{
    param( [string]$omsrg)
    $oms = Get-AzOperationalInsightsWorkspace -ResourceGroupName $omsrg
    return $oms
}


Function Get-Token { 
    param( $connection,[string]$uri)
    $formData = @{
      client_id = $connection.client_id
      client_secret = $connection.client_secret
      scope = 'openid profile offline_access'
      grant_type = 'client_credentials'
      resource = $connection.resource_id
    }
  
    Write-Host "getting token"
    $azureAdToken = Invoke-RestMethod -Uri $uri -Method Post -Body $formData -ContentType "application/x-www-form-urlencoded"
    #Write-Host $azureAdToken
    return $azureAdToken.access_token
}

Function get-vnet(){
    param([string]$vnetName,[string]$spnId,[string]$spnSecret)
    $connection = @{
        client_id = $spnId #SPN id
        client_secret = $spnSecret #SPN secret
        tenant_id = "5b973f99-77df-4beb-b27d-aa0c70b8482c" #tenant id
        resource_id = "24503ecb-840d-4109-be5e-f96e182d709d" #APP id that you are requesting to token to access to corresponding OAuth client credentials (attached to a $connection object).
    }
    $uri = 'https://login.microsoftonline.com/' + $connection.tenant_id + '/oauth2/token'
    
    $token = Get-Token $connection $uri
    $headers = New-Object "System.Collections.Generic.Dictionary[[String],[String]]"
    $headers.Add("Authorization", 'Bearer ' + $token)
    $requestUri = 'https://apis.000ukso.sbp.eyclienthub.com/ipam/api/orgs/CoDev/VNETs/' + $vnetName
    #$requestUri
    try{
        $res = Invoke-RestMethod  -Header $headers -Uri $requestUri -Method 'GET' -ContentType 'application/json' -Verbose
        $retcode = '200'
    }
    catch{
        errorResponse
    }
    return $retcode
}
Function get-subnet(){
    param([string]$subnetName,[string]$spnId,[string]$spnSecret)
    $connection = @{
        client_id = $spnId #SPN id
        client_secret = $spnSecret #SPN secret
        tenant_id = "5b973f99-77df-4beb-b27d-aa0c70b8482c" #tenant id
        resource_id = "24503ecb-840d-4109-be5e-f96e182d709d" #APP id that you are requesting to token to access to corresponding OAuth client credentials (attached to a $connection object).
    }
    $uri = 'https://login.microsoftonline.com/' + $connection.tenant_id + '/oauth2/token'
    
    $token = Get-Token $connection $uri
    $headers = New-Object "System.Collections.Generic.Dictionary[[String],[String]]"
    $headers.Add("Authorization", 'Bearer ' + $token)
    $requestUri = 'https://apis.000ukso.sbp.eyclienthub.com/ipam/api/orgs/CoDev/Subnets/' + $subnetName
    #$requestUri
    try{
        $res = Invoke-RestMethod  -Header $headers -Uri $requestUri -Method 'GET' -ContentType 'application/json' -Verbose
        $retcode = '200'
    }
    catch{
        errorResponse
    }
    return $retcode
}

Function errorResponse{
    $result = $_.Exception.Response.GetResponseStream()
    $reader = New-Object System.IO.StreamReader($result)
    $reader.BaseStream.Position = 0
    $reader.DiscardBufferedData()
    $responseBody = $reader.ReadToEnd()
    Write-Output $responseBody
    break
}

$resourceGroups = Get-AzResourceGroup
$resources = @()
$omsworkspace = get-oms $omsResourceGroup
$workspaceID = $omsworkspace.CustomerId
$workspaceName = $omsworkspace.Name
$bbCiphers = @("TLS_ECDHE_RSA_WITH_AES_256_GCM_SHA384","TLS_DHE_RSA_WITH_AES_128_GCM_SHA256","TLS_ECDHE_ECDSA_WITH_AES_128_GCM_SHA256","TLS_ECDHE_ECDSA_WITH_AES_256_GCM_SHA384","TLS_ECDHE_ECDSA_WITH_AES_256_CBC_SHA384")
$keyvault_collections = @()
$storage_collections = @()
$db_collections = @()
$sql_collections = @()
$networks = @()
$report = New-Object -TypeName PSCustomObject

foreach($rg in $resourceGroups){
    $resources += Get-AzResource -ResourceGroupName $rg.ResourceGroupName
}

foreach($resource in $resources){
    switch($resource.ResourceType)
    {
        'Microsoft.KeyVault/vaults'
        {
            $LogDiagnostics = "Not compliant"
            $owner = "Not compliant"
            $deployment_id = "Not compliant"
            $engagement_id = "Not compliant"
            $bb_not_used = ""
            $kv = New-Object -TypeName PSCustomObject
            $keyvaultName = $resource.Name
            $rgName = $resource.ResourceGroupName
            $type = "keyvault"
            $tags = $resource.Tags
            $keyvault = (Get-AzKeyVault -VaultName $resource.Name)
            $diag = Get-AzDiagnosticSetting -ResourceId $keyvault.ResourceId -ErrorAction SilentlyContinue
        
            if($diag){
                $diagID = $diag.WorkspaceId.Split("/")[-1]
                if($diagID -eq $workspaceName){
                    $omsDeviation = "no"
                }
                else{
                    $omsDeviation = "yes"
                }
                foreach($i in $diag.Logs){
                    if($i.Enabled -eq $true){
                        $LogDiagnostics = "Enabled"
                    }
                    else{
                        $LogDiagnostics = "Not compliant"
                    }
                }        
            }
            else{
                $diagID = "Not compliant"
                $omsDeviation = "yes"
            }
        
            if($tags){
                foreach($tag in $tags){
                    if(!$tag.ContainsKey("BUILDING_BLOCK") -or !$tag.ContainsKey("DEPLOYMENT_ID")){
                        $bb_not_used = "Possibly not"
                    }
                    else{
                        $bb_not_used = "used"
                    }
                    if($tag.ContainsKey("DEPLOYMENT_ID")){
                        $deployment_id = $tag.Item("DEPLOYMENT_ID")
                    }
                    if($tag.ContainsKey("OWNER")){
                        $owner = $tag.Item("OWNER")
                    }
                    if($tag.ContainsKey("ENGAGEMENT_ID")){
                        $engagement_id = $tag.Item("ENGAGEMENT_ID")
                    }
                }
            }
            else{
                $bb_not_used = "Possibly not"
            }
            $kv | Add-Member -MemberType noteproperty -Name subscription -Value $subscription_name -Force
            $kv | Add-Member -MemberType noteproperty -Name keyvault_name -Value $keyvaultName -Force
            $kv | Add-Member -MemberType noteproperty -Name type -Value $type -Force
            $kv | Add-Member -MemberType noteproperty -Name resource_group -Value $rgName -Force
            $kv | Add-Member -MemberType noteproperty -Name deployment_id -Value $deployment_id -Force
            $kv | Add-Member -MemberType noteproperty -Name owner -Value $owner -Force
            $kv | Add-Member -MemberType noteproperty -Name engagement_id -Value $engagement_id -Force
            $kv | Add-Member -MemberType noteproperty -Name building_block -Value $bb_not_used -Force
            $kv | Add-Member -MemberType noteproperty -Name keyvault_softdelete -Value $keyvault.EnableSoftDelete -Force
            $kv | Add-Member -MemberType noteproperty -Name oms_id -Value $diagID -Force
            $kv | Add-Member -MemberType noteproperty -Name oms_deviation -Value $omsDeviation -Force
            $kv | Add-Member -MemberType noteproperty -Name log_diagnositcs -Value $LogDiagnostics -Force
            #$kv
            $keyvault_collections += $kv
        }
        'Microsoft.Storage/storageAccounts'
        {
            $bb_not_used = ""
            $sta = New-Object -TypeName PSCustomObject
            $storageName = $resource.Name
            $rgName = $resource.ResourceGroupName
            $type = "storage containers"
            $tags = $resource.Tags
            $keys = Get-AzStorageAccountKey -ResourceGroupName $rgName -Name $storageName -ErrorAction SilentlyContinue
            $key = $keys[0].Value
            $context = New-AzStorageContext -StorageAccountName $storageName -StorageAccountKey $key
            $containers = Get-AzStorageContainer -Context $context -ErrorAction SilentlyContinue
            $diagID = "Diagnostics not applicable"
            $owner = "Not compliant"
            $deployment_id = "Not compliant"
            $engagement_id = "Not compliant"
        
            if($tags){
                foreach($tag in $tags){
                    if(!$tag.ContainsKey("BUILDING_BLOCK") -or !$tag.ContainsKey("DEPLOYMENT_ID")){
                        $bb_not_used = "Possibly not"
                    }
                    else{
                        $bb_not_used = "used"
                    }
                    if($tag.ContainsKey("DEPLOYMENT_ID")){
                        $deployment_id = $tag.Item("DEPLOYMENT_ID")
                    }
                    if($tag.ContainsKey("OWNER")){
                        $owner = $tag.Item("OWNER")
                    }
                    if($tag.ContainsKey("ENGAGEMENT_ID")){
                        $engagement_id = $tag.Item("ENGAGEMENT_ID")
                    }
                }
            }
            else{
                $bb_not_used = "Possibly not"
            }
            $sta | Add-Member -MemberType noteproperty -Name subscription -Value $subscription_name -Force
            $sta | Add-Member -MemberType noteproperty -Name storage_account -Value $storageName -Force
            $sta | Add-Member -MemberType noteproperty -Name type -Value $type -Force
            $sta | Add-Member -MemberType noteproperty -Name resource_group -Value $rgName -Force
            $sta | Add-Member -MemberType noteproperty -Name deployment_id -Value $deployment_id -Force
            $sta | Add-Member -MemberType noteproperty -Name owner -Value $owner -Force
            $sta | Add-Member -MemberType noteproperty -Name engagement_id -Value $engagement_id -Force
            $sta | Add-Member -MemberType noteproperty -Name building_block -Value $bb_not_used -Force
            $sta | Add-Member -MemberType noteproperty -Name oms_id -Value $diagID -Force
            foreach($container in $containers){
                if($container.PublicAccess -eq "Off"){
                    $compliantStatus = "Off"
                }
                else{
                    $compliantStatus = "Not Compliant"
                }
                $sta | Add-Member -MemberType noteproperty -Name container_name -Value $container.Name -Force
                $sta | Add-Member -MemberType noteproperty -Name public_access -Value $compliantStatus -Force
            }
            $storage_collections += $sta   
        }
        'Microsoft.Sql/servers/databases'
        {
            $LogDiagnostics = "Not compliant"
            $owner = "Not compliant"
            $deployment_id = "Not compliant"
            $engagement_id = "Not compliant"
            $bb_not_used = ""
            $sdb = New-Object -TypeName PSCustomObject
            $dbname = $resource.Name.Split("/")[1]
            $type = "sql database"
            $rgName = $resource.ResourceGroupName
            $tags = $resource.Tags
            $sqlserver = $resource.Name.Split("/")[0]
            if($dbname -eq "master"){
                continue
            }
            if($tags){
                foreach($tag in $tags){
                    if(!$tag.ContainsKey("BUILDING_BLOCK") -or !$tag.ContainsKey("DEPLOYMENT_ID")){
                        $bb_not_used = "Possibly not"
                    }
                    else{
                        $bb_not_used = "used"
                    }
                    if($tag.ContainsKey("DEPLOYMENT_ID")){
                        $deployment_id = $tag.Item("DEPLOYMENT_ID")
                    }
                    if($tag.ContainsKey("OWNER")){
                        $owner = $tag.Item("OWNER")
                    }
                    if($tag.ContainsKey("ENGAGEMENT_ID")){
                        $engagement_id = $tag.Item("ENGAGEMENT_ID")
                    }
                }
            }
            else{
                $bb_not_used = "Possibly not"
            }
            $diag = Get-AzDiagnosticSetting -ResourceId $resource.ResourceId -ErrorAction SilentlyContinue
            if($diag){
                $diagID = $diag.WorkspaceId.Split("/")[-1]
                if($diagID -eq $workspaceName){
                    $omsDeviation = "no"
                }
                else{
                    $omsDeviation = "yes"
                }
                foreach($i in $diag.Logs){
                    if($i.Category -ne "SQLSecurityAuditEvents" -and $i.Category -ne "DevOpsOperationsAudit"){
                        if($i.Enabled -eq $true){
                            $LogDiagnostics = "Enabled"
                        }
                        else{
                            $LogDiagnostics = "Not compliant"
                        }
                    }
                }       
            }
            else{
                $diagID = "Not compliant"
                $omsDeviation = "yes"
            }
            $sterm = (Get-AzSqlDatabaseBackupShortTermRetentionPolicy -ResourceGroupName $rgName -ServerName $sqlserver -DatabaseName $dbname -ErrorAction SilentlyContinue).RetentionDays 
            if($sterm -ge 14){
                $pitrBackup = $sterm
            }
            else{
                $pitrBackup = "Not compliant"
            }

            $lterm = Get-AzSqlDatabaseBackupLongTermRetentionPolicy -ResourceGroupName $rgName -ServerName $sqlserver -DatabaseName $dbname -ErrorAction SilentlyContinue
            $weekRetention = $lterm.WeeklyRetention
            $wRetInt = ($weekRetention -replace "[^0-9]" , '') 
            if($wRetInt -ne 0){
                $wBackup = $wRetInt + " Weeks"
            }
            else{
                $wBackup = "Not compliant"
            }
            
            $monthRetention = $lterm.MonthlyRetention
            $mRetInt = ($monthRetention -replace "[^0-9]" , '')
            if($mRetInt -ne 0){
                $mBackup = $mRetInt + " Months"
            }
            else{
                $mBackup = "Not compliant"
            }
            $yearRetention = $lterm.YearlyRetention
            $yRetInt = ($yearRetention -replace "[^0-9]" , '') + " Years"
            $threatProtection = Get-AzSqlDatabaseAdvancedThreatProtectionSetting -ResourceGroupName $rgName -DatabaseName $dbname -ServerName $sqlserver -ErrorAction SilentlyContinue
        
            if($threatProtection.ThreatDetectionState -eq "Enabled"){
                $threatPolicy = "Enabled"
            }
            else{
                $threatPolicy = "Not compliant"
            }
            $sdb | Add-Member -MemberType noteproperty -Name subscription -Value $subscription_name -Force
            $sdb | Add-Member -MemberType noteproperty -Name database_name -Value $dbname -Force
            $sdb | Add-Member -MemberType noteproperty -Name type -Value $type -Force
            $sdb | Add-Member -MemberType noteproperty -Name sql_server -Value $sqlserver -Force
            $sdb | Add-Member -MemberType noteproperty -Name resource_group -Value $rgName -Force
            $sdb | Add-Member -MemberType noteproperty -Name deployment_id -Value $deployment_id -Force
            $sdb | Add-Member -MemberType noteproperty -Name owner -Value $owner -Force
            $sdb | Add-Member -MemberType noteproperty -Name engagement_id -Value $engagement_id -Force
            $sdb | Add-Member -MemberType noteproperty -Name building_block -Value $bb_not_used -Force
            $sdb | Add-Member -MemberType noteproperty -Name oms_id -Value $diagID -Force
            $sdb | Add-Member -MemberType noteproperty -Name oms_deviation -Value $omsDeviation -Force
            $sdb | Add-Member -MemberType noteproperty -Name log_diagnositcs -Value $LogDiagnostics -Force
            $sdb | Add-Member -MemberType noteproperty -Name short_tem_backup -Value $pitrBackup -Force
            $sdb | Add-Member -MemberType noteproperty -Name weekly_retention -Value $wBackup -Force
            $sdb | Add-Member -MemberType noteproperty -Name monthly_diagnostics -Value $mBackup -Force
            $sdb | Add-Member -MemberType noteproperty -Name threat_protection -Value $threatPolicy -Force
            $db_collections += $sdb
        }
        'Microsoft.Sql/servers'
        {
            $sqlName = $resource.Name
            $rgName = $resource.ResourceGroupName
            $type = "sql server"
            $tags = $resource.Tags
            $owner = ""
            $deployment_id = ""
            $engagement_id = ""
            $bb_not_used = ""
            $sql = New-Object -TypeName PSCustomObject

            $tls = (Get-AzSqlServer -ServerName $sqlName -ResourceGroupName $rgName).MinimalTlsVersion
            if($tls -eq "1.2"){
                $tlsVersion = "1.2"
            }
            else{
                $tlsVersion = "Not Compliant"
            }
            $sqlAdmin = (Get-AzSqlServerActiveDirectoryAdministrator -ServerName $sqlName -ResourceGroupName $rgName).DisplayName
        
            if($sqlerr){
                $sqladminconfig = "Not compliant"
            }
            else{
                $sqladminconfig = $sqlAdmin
            }

            $sqlThreatPolicy = (Get-AzSqlServerAdvancedThreatProtectionSetting -ServerName $sqlName -ResourceGroupName $rgName).ThreatDetectionState
            if($sqlThreatPolicy -eq "Enabled"){
                $threatPolicy = "Enabled"
            }
            else{
                $threatPolicy = "Not compliant"
            }
            $tde = Get-AzSqlServerTransparentDataEncryptionProtector -ResourceGroupName $rgName -ServerName $sqlName
            if($tde.Type -eq "ServiceManaged"){
                $tdekey = "ServiceManaged"
            }
            else{
                $tdeKey = $tde.ServerKeyVaultKeyName + '_' + $tde.KeyId
            }
            $vs = Get-AzSqlServerVulnerabilityAssessmentSetting -ServerName $sqlName -ResourceGroupName $rgName
            if($vs.EmailAdmins -eq $false -and $vs.RecurringScansInterval -eq "None"){
                $vsreport = "Not compliant"
            }
            else{
                 $vsreport = "scan is set"
            }
            if($tags){
                foreach($tag in $tags){
                    if(!$tag.ContainsKey("BUILDING_BLOCK") -or !$tag.ContainsKey("DEPLOYMENT_ID") -or !$tag.ContainsKey("TOWER_JOB_ID")){
                        $bb_not_used = "Possibly not"
                    }
                    else{
                        $bb_not_used = "used"
                    }
                    if($tag.ContainsKey("DEPLOYMENT_ID")){
                        $deployment_id = $tag.Item("DEPLOYMENT_ID")
                    }
                    else{
                         $deployment_id = ""
                    }
                    if($tag.ContainsKey("OWNER")){
                        $owner = $tag.Item("OWNER")
                    }
                    else{
                        $owner = ""
                    }
                    if($tag.ContainsKey("ENGAGEMENT_ID")){
                        $engagement_id = $tag.Item("ENGAGEMENT_ID")
                    }
                    else{
                        $engagement_id = ""
                    }
                }
            }
            else{
                $bb_not_used = "Possibly not"
            }
            $diagID = "Diagnostics not applicable"
            $sql | Add-Member -MemberType noteproperty -Name subscription -Value $subscription_name -Force
            $sql | Add-Member -MemberType noteproperty -Name database_name -Value $sqlName -Force
            $sql | Add-Member -MemberType noteproperty -Name type -Value $type -Force
            $sql | Add-Member -MemberType noteproperty -Name resource_group -Value $rgName -Force
            $sql | Add-Member -MemberType noteproperty -Name deployment_id -Value $deployment_id -Force
            $sql | Add-Member -MemberType noteproperty -Name owner -Value $owner -Force
            $sql | Add-Member -MemberType noteproperty -Name engagement_id -Value $engagement_id -Force
            $sql | Add-Member -MemberType noteproperty -Name building_block -Value $bb_not_used -Force
            $sql | Add-Member -MemberType noteproperty -Name tls_version -Value $tlsVersion -Force
            $sql | Add-Member -MemberType noteproperty -Name sql_admin_config -Value $sqladminconfig -Force
            $sql | Add-Member -MemberType noteproperty -Name sql_threat_policy -Value $threatPolicy -Force
            $sql | Add-Member -MemberType noteproperty -Name sql_tde -Value $tdekey -Force
            $sql | Add-Member -MemberType noteproperty -Name vulnerabiltiy_scan -Value $vsreport -Force
            $sql_collections += $sql
        }
        'Microsoft.Network/virtualNetworks'
        {
            $rgName = $resource.ResourceGroupName
            $vnetName = $resource.Name
            $tags = $resource.Tags
            $findvnet = get-vnet $vnetName $spnID $spnSecret
            $owner = ""
            $deployment_id = ""
            $engagement_id = ""
            $bb_not_used = ""
            $vnt = New-Object -TypeName PSCustomObject
            $sbn = New-Object -TypeName PSCustomObject

            if($findvnet -eq '200'){
                $vnetStatus = "Registered"
            }
            else{
                $vnetStatus = "Not compliant"
            }
            $diag = Get-AzDiagnosticSetting -ResourceId $resource.ResourceId
            if($diag){
                $diagID = $diag.WorkspaceId.Split("/")[-1]
                if($diagID -eq $workspaceName){
                    $omsDeviation = "no"
                }
                else{
                    $omsDeviation = "yes"
                }
                foreach($i in $diag.Logs){
                    if($i.Enabled -eq $true){
                        $LogDiagnostics = "Enabled"
                    }
                    else{
                        $LogDiagnostics = "Not compliant"
                    }
                }        
            }
            else{
                $diagID = "Diagnostics not available"
            }
            if($tags){
                foreach($tag in $tags){
                    if(!$tag.ContainsKey("BUILDING_BLOCK") -or !$tag.ContainsKey("DEPLOYMENT_ID")){
                        $bb_not_used = "Possibly not"
                    }
                    else{
                        $bb_not_used = "used"
                    }
                    if($tag.ContainsKey("DEPLOYMENT_ID")){
                        $deployment_id = $tag.Item("DEPLOYMENT_ID")
                    }
                    else{
                         $deployment_id = ""
                    }
                    if($tag.ContainsKey("OWNER")){
                        $owner = $tag.Item("OWNER")
                    }
                    else{
                        $owner = ""
                    }
                    if($tag.ContainsKey("ENGAGEMENT_ID")){
                        $engagement_id = $tag.Item("ENGAGEMENT_ID")
                    }
                    else{
                        $engagement_id = ""
                    }
                }
            }
            else{
                $bb_not_used = "Possibly not"
            }
            
            $vnt | Add-Member -MemberType noteproperty -Name subscription -Value $subscription_name -Force
            $vnt | Add-Member -MemberType noteproperty -Name vnet_name -Value $vnetName -Force
            $vnt | Add-Member -MemberType noteproperty -Name type -Value $type -Force
            $vnt | Add-Member -MemberType noteproperty -Name resource_group -Value $rgName -Force
            $vnt | Add-Member -MemberType noteproperty -Name deployment_id -Value $deployment_id -Force
            $vnt | Add-Member -MemberType noteproperty -Name owner -Value $owner -Force
            $vnt | Add-Member -MemberType noteproperty -Name engagement_id -Value $engagement_id -Force
            $vnt | Add-Member -MemberType noteproperty -Name building_block -Value $bb_not_used -Force
            $vnt | Add-Member -MemberType noteproperty -Name oms_id -Value $diagID -Force
            $vnt | Add-Member -MemberType noteproperty -Name oms_deviation -Value $omsDeviation -Force
            $vnt | Add-Member -MemberType noteproperty -Name log_diagnositcs -Value $LogDiagnostics -Force
            $vnt | Add-Member -MemberType noteproperty -Name ipam_registration -Value $vnetStatus -Force
            $networks += $vnt

            $vnet = Get-AzVirtualNetwork -ResourceGroupName $rgName -Name $vnetName
            $subnetName = ""
            foreach($subnet in $vnet.Subnets){
                $subnetName = $subnet.Name
                $findsubnet = get-subnet $subnetName $spnID $spnSecret
                if($findsubnet -eq '200'){
                    $subnetStatus = "Registered"
                }
                else{
                    $subnetStatus = "Not compliant"
                }
            }
            $sbn | Add-Member -MemberType noteproperty -Name subnet_name -Value $subnetName -Force
            $sbn | Add-Member -MemberType noteproperty -Name virtual_network -Value $vnetName -Force
            $sbn | Add-Member -MemberType noteproperty -Name ipam_registration -Value $subnetStatus -Force
            $networks += $sbn
        }
            
    }
}

$report | Add-Member -MemberType noteproperty -Name keyvault -Value $keyvault_collections -Force
$report | Add-Member -MemberType noteproperty -Name storageaccount -Value $storage_collections -Force
$report | Add-Member -MemberType noteproperty -Name sql_database -Value $db_collections -Force
$report | Add-Member -MemberType noteproperty -Name sql_server -Value $sql_collections -Force
$report | Add-Member -MemberType noteproperty -Name virtual_networks -Value $networks -Force


$report | ConvertTo-Json | Out-File "C:\Users\LK757HL\Documents\EY documents\scripts\project1\compliancereport\output.json"

$json = Get-Content "C:\Users\LK757HL\Documents\EY documents\scripts\project1\compliancereport\output.json" | ConvertFrom-Json
$date = Get-Date -Format "yyyy-MM-ddTHHmms"
$excelfile = "C:\Users\LK757HL\Documents\EY documents\scripts\project1\scan_$date.xlsx"
$title = "Compliance Scan Report"
Import-Module ImportExcel
#$cd = New-ExcelChartDefinition -Title "PITR Backup" -ChartType BarClustered -XRange database_name -YRange short_tem_backup 
$xls = ""
$json | Get-Member -MemberType NoteProperty | ForEach-Object {
    $key = $_.Name
    Write-Host $key
    $value = $json."$key"
    foreach($k in $value){
        $k | Export-Excel $excelfile -WorksheetName $key -AutoSize -Append -AutoFilter -BoldTopRow  -ConditionalText (New-ConditionalText -ConditionalType Equal "Not compliant") -FreezeTopRow
    }
}

#$xls = Open-ExcelPackage -Path $excelfile

#$pt = Add-PivotTable -ExcelPackage $xls -SourceWorksheet $xls.sql_database -SourceRange "A1:P55" -PivotRows weekly_retention -PivotData @{'database_name'='Count'} -PivotTableName "compliancescan"
#Close-ExcelPackage $xls -Show