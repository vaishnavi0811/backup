﻿param(
    [Parameter(Mandatory=$true)]

    $spnID,
    [Parameter(Mandatory=$true)]
    [securestring]
    $spnSecret,
    [Parameter(Mandatory=$true)]
    [string]
    $resourcegroupname
)

$cred = New-Object pscredential -ArgumentList $spnID,$spnSecret
Connect-AzAccount -Credential $cred -ServicePrincipal -Tenant a1319080-2db0-4f77-afdf-826779c04f8e

Get-AzResourceGroup -Name $resourcegroupname -ErrorVariable notPresent -ErrorAction SilentlyContinue | Format-Table

if ($notPresent) 
{
    Write-Output "Resource group doesnot exist"
    break
}

$resources = Get-AzResource -ResourceGroupName $resourcegroupname
$resources

$vnet = Get-AzVirtualNetwork -Name "myvnet" -ResourceGroupName $resourcegroupname | Select Subnets
$s = $vnet.Subnets
$s.GetType()

$subnet = Get-AzVirtualNetworkSubnetConfig -Name sbn01 -VirtualNetwork $vnet

Get-AzResource -ResourceId $subnet.IpConfigurations[0].id
